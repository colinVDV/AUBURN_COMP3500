Project 5 for Comp3500

This. Was fun, but also... Not fun. That is all.