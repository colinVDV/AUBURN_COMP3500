//This is a handler file for displayStat.c, very important.

#ifndef _DISPLAYSTAT_H_
#define _DISPLAYSTAT_H_

void displayStat(float averageWaitingTime, float averageTurnaroundTime, float averageResponseTime);

#endif
